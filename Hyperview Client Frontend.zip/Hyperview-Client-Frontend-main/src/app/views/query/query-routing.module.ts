import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { QueryComponent } from "./query.component";

const routes: Routes = [
  {
    path: "",
    component: QueryComponent,
    data: {
      title: "Query",
      permission: "queries.list",
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class QueryRoutingModule {}
